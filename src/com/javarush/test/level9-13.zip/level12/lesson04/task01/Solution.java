package com.javarush.test.level12.lesson04.task01;

/* print(int) и print(String)
Написать два метода: print(int) и print(String).
*/

public class Solution
{
    public static void main(String[] args)
    {

    }

    public int print (int a)
    {
        return a;
    }
    public String print (String s)
    {
        return s;
    }
}
