package com.javarush.test.level13.lesson11.bonus02;

public interface RepkaItem
{
    public String getNamePadezh();
}
