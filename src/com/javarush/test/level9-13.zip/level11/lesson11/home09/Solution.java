package com.javarush.test.level11.lesson11.home09;

/* Четвертая правильная «цепочка наследования»
Расставь правильно «цепочку наследования» в классах: House (дом), Cat (кот), Dog(собака), Car (машина).
*/

public class Solution
{
    public static void main(String[] args)
    {
    }

    public class House
    {

    }

    public class Cat
    {

    }

    public class Car
    {

    }

    public class Dog
    {

    }
}
