package com.javarush.test.level11.lesson11.bonus02;

/* Нужно добавить в программу новую функциональность
Добавь общий базовый класс к классам-фигур:  (фигуры из шахмат).
*/

public class Solution
{
    public static void main(String[] args)
    {
    }
    public class Chess
    {
    }

    public class King extends Chess
    {
    }

    public class Queen extends Chess
    {
    }

    public class Rook extends Chess
    {
    }

    public class Knight extends Chess
    {
    }

    public class Bishop extends Chess
    {
    }

    public class Pawn extends Chess
    {
    }
}
